module Bootstrap
  VERSION = '3.3.0.0'
  BOOTSTRAP_SHA = '16dbdbd7a2c6cfa3be4e5dcc52249e577c02c84a'
end
